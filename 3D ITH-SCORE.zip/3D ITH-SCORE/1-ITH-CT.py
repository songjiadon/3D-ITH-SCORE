import os
import tkinter as tk
from tkinter import filedialog, simpledialog
import nibabel as nib
import numpy as np
from scipy.ndimage import gaussian_filter, label as scipy_label, generate_binary_structure
from sklearn.cluster import KMeans
import logging

# -------------------------- Log Configuration --------------------------
logging.basicConfig(
    filename="Pancreatic_CT_ITH_Analysis.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filemode="w"
)
logger = logging.getLogger(__name__)


class PancreaticCTITHAnalyzer:
    def __init__(
        self,
        hu_min=-100,
        hu_max=200,
        smooth_sigma=0.8,
        max_cluster_ratio=0.75,
        min_tumor_voxels=150
    ):
        self.seq_num = 0
        self.image_dirs = []
        self.mask_dir = None
        self.output_dir = None
        self.local_std_seq_idx = 0

        self.hu_min = hu_min
        self.hu_max = hu_max
        self.smooth_sigma = smooth_sigma
        self.max_cluster_ratio = max_cluster_ratio
        self.min_tumor_voxels = min_tumor_voxels

        # 3D 6‑connectivity structure for connected‑component analysis
        self.connect_struct = generate_binary_structure(3, 1)

        self.results = []
        self.error_patients = []   # Store failed patient IDs

    def select_folders(self):
        root = tk.Tk()
        root.withdraw()

        seq_input = simpledialog.askinteger(
            "Input number of sequences",
            "Please input how many CT sequences you have:",
            minvalue=1, maxvalue=10
        )
        if seq_input is None:
            logger.error("User cancelled sequence number input")
            return False
        self.seq_num = seq_input

        self.image_dirs = []
        for idx in range(self.seq_num):
            d = filedialog.askdirectory(title=f"Select folder for Sequence {idx+1} (.nii.gz)")
            if not d:
                logger.error(f"User cancelled selection for Sequence {idx+1} folder")
                return False
            self.image_dirs.append(d)

        std_seq_input = simpledialog.askinteger(
            "Select sequence for local‑std feature",
            f"Which sequence is used to calculate local std enhancement?\nInput number: 1 ~ {self.seq_num}",
            minvalue=1, maxvalue=self.seq_num
        )
        if std_seq_input is None:
            logger.error("User cancelled local‑std sequence selection")
            return False
        self.local_std_seq_idx = std_seq_input - 1

        self.mask_dir = filedialog.askdirectory(title="Select Tumor ROI folder (.nii.gz)")
        if not self.mask_dir:
            return False
        self.output_dir = filedialog.askdirectory(title="Select output folder")
        if not self.output_dir:
            return False

        logger.info(f"Total sequences: {self.seq_num}")
        for i, p in enumerate(self.image_dirs):
            logger.info(f"Sequence {i+1}: {p}")
        logger.info(f"Local‑std enhancement uses Sequence: {self.local_std_seq_idx+1}")
        logger.info(f"ROI directory: {self.mask_dir}, Output directory: {self.output_dir}")
        return True

    def enhance_features(self, img_data, mask, voxel_dims):
        window_size_mm = 5
        win_size = np.ceil(window_size_mm / np.array(voxel_dims)).astype(int)
        from scipy.ndimage import uniform_filter
        local_mean = uniform_filter(img_data, size=win_size)
        local_mean_sq = uniform_filter(img_data ** 2, size=win_size)
        local_var = local_mean_sq - local_mean ** 2
        local_var[local_var < 0] = 0
        local_std = np.sqrt(local_var)
        feat = local_std[mask].reshape(-1, 1)
        feat = (feat - np.mean(feat)) / (np.std(feat) + 1e-6)
        return feat

    def find_best_cluster_number(self, feature_matrix, cluster_range):
        ch_scores = []
        from sklearn.metrics import calinski_harabasz_score
        for n in cluster_range:
            km = KMeans(n_clusters=n, random_state=42, n_init=5)
            labels = km.fit_predict(feature_matrix)
            ch = calinski_harabasz_score(feature_matrix, labels)
            ch_scores.append(ch)
        best_idx = int(np.argmax(ch_scores))
        best_n = cluster_range[best_idx]
        return best_n, ch_scores, list(cluster_range)

    def calculate_ith_score(self, cluster_map, mask_data, voxel_volume, patient_id):
        """
        Re‑implement ITHscore from Li et al. European Radiology 2023
        Formula: ITHscore = 1 − (1/V_total) * Σ (V_{i,max}/n_i )
        n_i: number of connected components for cluster i
        V_{i,max}: volume of largest connected component within cluster i
        Output range: [0, 1]
        """
        tumor_mask = mask_data > 0
        total_vol = np.sum(tumor_mask) * voxel_volume

        unique_clusters = np.unique(cluster_map[tumor_mask])
        unique_clusters = unique_clusters[unique_clusters != 0]

        if len(unique_clusters) < 2:
            logger.warning(f"Patient {patient_id}: valid clusters < 2, set ITHscore=0.01")
            return 0.01, 1.0

        sum_term = 0.0
        cluster_volumes = []

        for c_label in unique_clusters:
            sub_mask = (cluster_map == c_label) & tumor_mask
            labeled_cc, n_cc = scipy_label(sub_mask, structure=self.connect_struct)
            if n_cc == 0:
                continue
            vol_list = []
            for cc_idx in range(1, n_cc + 1):
                cc_vol = np.sum(labeled_cc == cc_idx) * voxel_volume
                vol_list.append(cc_vol)
            v_i_max = np.max(vol_list)
            n_i = n_cc
            sum_term += (v_i_max / n_i)
            cluster_volumes.append(np.sum(sub_mask) * voxel_volume)

        ith_score = 1.0 - (sum_term / total_vol)
        ith_score = float(np.clip(ith_score, 0.0, 1.0))

        max_cluster_vol = float(np.max(cluster_volumes))
        max_cluster_ratio = max_cluster_vol / total_vol

        return ith_score, max_cluster_ratio

    def process_single_patient(self, fname):
        patient_id = os.path.splitext(os.path.splitext(fname)[0])[0]
        logger.info(f"\n===== Processing Patient: {patient_id} =====")
        print(f"\n===== Processing Patient: {patient_id} =====")

        seq_nib_list = []
        seq_data_list = []
        try:
            for seq_idx, img_dir in enumerate(self.image_dirs):
                img_path = os.path.join(img_dir, fname)
                if not os.path.exists(img_path):
                    raise FileNotFoundError(f"Sequence {seq_idx+1} file missing: {img_path}")
                nii = nib.load(img_path)
                data = nii.get_fdata().astype(np.float32)
                seq_nib_list.append(nii)
                seq_data_list.append(data)

            mask_path = os.path.join(self.mask_dir, fname)
            if not os.path.exists(mask_path):
                raise FileNotFoundError(f"ROI file missing: {mask_path}")
            mask_nii = nib.load(mask_path)
            mask_data = mask_nii.get_fdata().astype(np.uint8)

            ref_shape = mask_data.shape
            for si, sd in enumerate(seq_data_list):
                if sd.shape != ref_shape:
                    raise ValueError(f"Sequence {si+1} shape mismatch with ROI")

            tumor_mask = mask_data > 0
            tumor_voxels = np.sum(tumor_mask)
            if tumor_voxels < self.min_tumor_voxels:
                logger.warning(f"Patient {patient_id}: tumor voxels {tumor_voxels} < threshold, skip")
                print(f"⚠️ Patient {patient_id}: tumor voxels too small, skip")
                return

            patient_out_dir = os.path.join(self.output_dir, patient_id)
            os.makedirs(patient_out_dir, exist_ok=True)

            norm_seq_list = []
            for sd in seq_data_list:
                sd = sd * tumor_mask
                sd = np.clip(sd, self.hu_min, self.hu_max)
                if self.smooth_sigma > 0:
                    sd = gaussian_filter(sd, sigma=self.smooth_sigma)
                norm_seq_list.append(sd)

            voxel_dims = mask_nii.header.get_zooms()

            tumor_indices = np.argwhere(tumor_mask)
            x = tumor_indices[:, 0] / mask_data.shape[0]
            y = tumor_indices[:, 1] / mask_data.shape[1]
            z = tumor_indices[:, 2] / mask_data.shape[2]
            coords = np.column_stack((x, y, z))

            multi_seq_voxels = []
            for sd in norm_seq_list:
                vox = sd[tumor_mask].reshape(-1, 1)
                vox = (vox - np.mean(vox)) / (np.std(vox) + 1e-6)
                multi_seq_voxels.append(vox)
            multi_seq_voxels = np.hstack(multi_seq_voxels)

            tumor_local_std = self.enhance_features(norm_seq_list[self.local_std_seq_idx], tumor_mask, voxel_dims)
            tumor_features = np.hstack((multi_seq_voxels, coords, tumor_local_std))

            if tumor_voxels < 1000:
                current_cluster_range = range(2, 7)
            else:
                current_cluster_range = range(2, 10)

            best_cluster_num, ch_scores, cluster_range = self.find_best_cluster_number(tumor_features, current_cluster_range)
            print(f"Optimal number of clusters: {best_cluster_num}")

            kmeans = KMeans(n_clusters=best_cluster_num, random_state=42, n_init=5)
            clusters = kmeans.fit_predict(tumor_features)

            cluster_map = np.zeros_like(mask_data, dtype=np.int16)
            cluster_map[tumor_mask] = clusters + 1
            cluster_nii = nib.Nifti1Image(cluster_map, mask_nii.affine, mask_nii.header)
            cluster_save_path = os.path.join(patient_out_dir, f"{patient_id}_multi_seq_cluster.nii.gz")
            nib.save(cluster_nii, cluster_save_path)

            voxel_volume = np.prod(voxel_dims)
            ith_score, max_cluster_ratio = self.calculate_ith_score(cluster_map, mask_data, voxel_volume, patient_id)

            cluster_quality = "Pass" if max_cluster_ratio <= self.max_cluster_ratio else "Warning"
            self.results.append({
                "PatientID": patient_id,
                "TumorVoxels": int(tumor_voxels),
                "OptimalClusterNum": best_cluster_num,
                "ITHscore": round(ith_score, 4),
                "MaxClusterRatio": round(max_cluster_ratio, 4),
                "ClusterQuality": cluster_quality,
                "LocalStdUsedSequence": self.local_std_seq_idx + 1
            })
            print(f"✅ {patient_id} done | ITHscore:{ith_score:.4f} MaxClusterRatio:{max_cluster_ratio:.3f}")

        except Exception as e:
            err_msg = f"Patient {patient_id} failed: {str(e)}"
            logger.error(err_msg, exc_info=True)
            print(f"❌ {err_msg} ——— skip and continue")
            self.error_patients.append(patient_id)

    def run_batch(self):
        if not self.select_folders():
            print("User cancelled setup, exit.")
            return

        file_list = [f for f in os.listdir(self.image_dirs[0]) if f.endswith(".nii.gz")]
        total = len(file_list)
        print(f"\nTotal patients to process: {total}")

        for idx, fname in enumerate(file_list):
            print(f"\n==== Progress {idx+1}/{total} ====")
            self.process_single_patient(fname)

        # ----------------Summary after all patients processed----------------
        print("\n" + "="*60)
        if len(self.error_patients) > 0:
            print(f"⚠️ Total failed patients count: {len(self.error_patients)}")
            print(f"⚠️ Failed patient ID list: {self.error_patients}")
            logger.info(f"Failed patient IDs: {self.error_patients}")
        else:
            print("✅ All patients processed without error")
            logger.info("All patients processed without error")
        print("="*60)

        # Save excel results
        import pandas as pd
        out_df = pd.DataFrame(self.results)
        excel_path = os.path.join(self.output_dir, "MultiSeq_ITHscore_Results.xlsx")
        out_df.to_excel(excel_path, index=False)
        print(f"\n✅ Result excel saved: {excel_path}")
        logger.info(f"Result excel saved: {excel_path}")


if __name__ == "__main__":
    analyzer = PancreaticCTITHAnalyzer()
    analyzer.run_batch()
