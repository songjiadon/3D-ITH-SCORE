import os
import tkinter as tk
from tkinter import filedialog, simpledialog
import nibabel as nib
import numpy as np
from scipy.ndimage import gaussian_filter, label as scipy_label, generate_binary_structure, uniform_filter
from sklearn.cluster import KMeans
import logging

# -------------------------- Log Configuration --------------------------
logging.basicConfig(
    filename="MultiSeq_MRI_ITH_Analysis.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filemode="w"
)
logger = logging.getLogger(__name__)


def gui_ask_integer(title, prompt, minvalue, maxvalue):
    """独立临时tk实例，用完销毁，防止弹窗循环重复弹出bug"""
    root = tk.Tk()
    root.withdraw()
    res = simpledialog.askinteger(title, prompt, minvalue=minvalue, maxvalue=maxvalue, parent=root)
    root.destroy()
    return res


def gui_ask_dir(title):
    """独立临时tk实例选择文件夹"""
    root = tk.Tk()
    root.withdraw()
    folder = filedialog.askdirectory(title=title, parent=root)
    root.destroy()
    return folder


class MultiSeqMRI_ITHAnalyzer:
    def __init__(
        self,
        smooth_sigma=1.0,
        max_cluster_ratio=0.85,
        min_tumor_voxels=150,
        lower_percentile=2,
        upper_percentile=98
    ):
        self.seq_num = 0
        self.image_dirs = []
        self.mask_dir = None
        self.output_dir = None
        self.local_std_seq_idx = 0

        self.smooth_sigma = smooth_sigma
        self.max_cluster_ratio = max_cluster_ratio
        self.min_tumor_voxels = min_tumor_voxels
        self.lower_percentile = lower_percentile
        self.upper_percentile = upper_percentile

        # 3D 6‑connectivity for connected‑component analysis
        self.connect_struct = generate_binary_structure(3, 1)

        self.results = []
        self.error_patients = []   # store failed patient IDs

    def select_folders(self):
        # -------- 全部使用封装好的独立GUI函数，每次调用新建销毁tk，不会残留 --------
        seq_input = gui_ask_integer(
            "Input number of MRI sequences",
            "Please input how many MRI sequences you have:",
            minvalue=1, maxvalue=10
        )
        if seq_input is None:
            logger.error("User cancelled sequence number input")
            return False
        self.seq_num = seq_input

        self.image_dirs = []
        for idx in range(self.seq_num):
            d = gui_ask_dir(title=f"Select folder for MRI Sequence {idx+1} (.nii.gz)")
            if not d:
                logger.error(f"User cancelled selection for MRI Sequence {idx+1} folder")
                return False
            self.image_dirs.append(d)

        std_seq_input = gui_ask_integer(
            "Select sequence for local‑std feature",
            f"Which MRI sequence is used to calculate local std enhancement?\nInput number: 1 ~ {self.seq_num}",
            minvalue=1, maxvalue=self.seq_num
        )
        if std_seq_input is None:
            logger.error("User cancelled local‑std sequence selection")
            return False
        self.local_std_seq_idx = std_seq_input - 1

        self.mask_dir = gui_ask_dir(title="Select Tumor ROI folder (.nii.gz, shared for all sequences)")
        if not self.mask_dir:
            return False
        self.output_dir = gui_ask_dir(title="Select output folder")
        if not self.output_dir:
            return False

        os.makedirs(self.output_dir, exist_ok=True)

        logger.info(f"Total MRI sequences: {self.seq_num}")
        for i, p in enumerate(self.image_dirs):
            logger.info(f"MRI Sequence {i+1}: {p}")
        logger.info(f"Local‑std enhancement uses MRI Sequence: {self.local_std_seq_idx+1}")
        logger.info(f"Intensity truncation: tumor mask inner {self.lower_percentile}‑{self.upper_percentile} percentile")
        logger.info(f"ROI directory: {self.mask_dir}, Output directory: {self.output_dir}")
        return True

    def enhance_features(self, img_data, mask, voxel_dims):
        window_size_mm = 5
        win_size = np.ceil(window_size_mm / np.array(voxel_dims)).astype(int)
        win_size = np.maximum(win_size, 1)
        win_size = np.minimum(win_size, 5)

        local_mean = uniform_filter(img_data, size=win_size)
        local_mean_sq = uniform_filter(img_data ** 2, size=win_size)
        local_var = local_mean_sq - local_mean ** 2
        local_var[local_var < 0] = 0
        local_std = np.sqrt(local_var)

        feat = local_std[mask].reshape(-1, 1)
        feat = (feat - np.mean(feat)) / (np.std(feat) + 1e-6)
        return feat

    def find_best_cluster_number(self, feature_matrix, cluster_range):
        from sklearn.metrics import calinski_harabasz_score
        ch_scores = []
        for n in cluster_range:
            km = KMeans(n_clusters=n, random_state=42, n_init=5)
            labels = km.fit_predict(feature_matrix)
            ch = calinski_harabasz_score(feature_matrix, labels)
            ch_scores.append(ch)
        best_idx = int(np.argmax(ch_scores))
        best_n = cluster_range[best_idx]
        return best_n, ch_scores, list(cluster_range)

    def calculate_ith_score(self, cluster_map, mask_data, voxel_volume, patient_id):
        """
        Re‑implement ITHscore from Li et al. European Radiology 2023
        Formula: ITHscore = 1 − (1/V_total) * Σ (V_{i,max}/n_i )
        n_i: number of connected components for cluster i
        V_{i,max}: volume of largest connected component within cluster i
        Output range: [0, 1]
        """
        tumor_mask = mask_data > 0
        total_vol = np.sum(tumor_mask) * voxel_volume

        unique_clusters = np.unique(cluster_map[tumor_mask])
        unique_clusters = unique_clusters[unique_clusters != 0]

        if len(unique_clusters) < 2:
            logger.warning(f"Patient {patient_id}: valid clusters < 2, set ITHscore=0.01")
            return 0.01, 1.0

        sum_term = 0.0
        cluster_volumes = []

        for c_label in unique_clusters:
            sub_mask = (cluster_map == c_label) & tumor_mask
            labeled_cc, n_cc = scipy_label(sub_mask, structure=self.connect_struct)
            if n_cc == 0:
                continue
            vol_list = []
            for cc_idx in range(1, n_cc + 1):
                cc_vol = np.sum(labeled_cc == cc_idx) * voxel_volume
                vol_list.append(cc_vol)
            v_i_max = np.max(vol_list)
            n_i = n_cc
            sum_term += (v_i_max / n_i)
            cluster_volumes.append(np.sum(sub_mask) * voxel_volume)

        ith_score = 1.0 - (sum_term / total_vol)
        ith_score = float(np.clip(ith_score, 0.0, 1.0))

        max_cluster_vol = float(np.max(cluster_volumes))
        max_cluster_ratio = max_cluster_vol / total_vol

        return ith_score, max_cluster_ratio

    def process_single_patient(self, fname):
        patient_id = os.path.splitext(os.path.splitext(fname)[0])[0]
        logger.info(f"\n===== Processing Patient: {patient_id} (Multi‑sequence MRI) =====")
        print(f"\n===== Processing Patient: {patient_id} =====")

        seq_nib_list = []
        seq_raw_data_list = []
        try:
            # load each MRI sequence
            for seq_idx, img_dir in enumerate(self.image_dirs):
                img_path = os.path.join(img_dir, fname)
                if not os.path.exists(img_path):
                    raise FileNotFoundError(f"MRI seq{seq_idx+1} file missing:{img_path}")
                nii = nib.load(img_path)
                data = nii.get_fdata().astype(np.float32)
                seq_nib_list.append(nii)
                seq_raw_data_list.append(data)

            mask_path = os.path.join(self.mask_dir, fname)
            if not os.path.exists(mask_path):
                raise FileNotFoundError(f"ROI mask file missing:{mask_path}")
            mask_nii = nib.load(mask_path)
            mask_data = mask_nii.get_fdata().astype(np.uint8)
            tumor_mask = mask_data > 0

            ref_shape = mask_data.shape
            for si, sd in enumerate(seq_raw_data_list):
                if sd.shape != ref_shape:
                    raise ValueError(f"MRI seq{si+1} shape mismatch with tumor ROI")

            tumor_voxels = np.sum(tumor_mask)
            if tumor_voxels < self.min_tumor_voxels:
                logger.warning(f"Patient {patient_id}: tumor voxels {tumor_voxels} < threshold, skip")
                print(f"⚠️ Patient {patient_id}: tumor voxels too small, skip")
                return

            patient_out_dir = os.path.join(self.output_dir, patient_id)
            os.makedirs(patient_out_dir, exist_ok=True)

            # ========== Per‑sequence: tumor‑inner 2‑98 percentile truncation ==========
            norm_seq_list = []
            for raw_data in seq_raw_data_list:
                # only use values inside tumor mask for percentile calculation
                tumor_vals = raw_data[tumor_mask]
                p_low = np.percentile(tumor_vals, self.lower_percentile)
                p_high = np.percentile(tumor_vals, self.upper_percentile)

                img = raw_data * tumor_mask
                img = np.clip(img, p_low, p_high)

                if self.smooth_sigma > 0:
                    img = gaussian_filter(img, sigma=self.smooth_sigma)
                norm_seq_list.append(img)

            voxel_dims = mask_nii.header.get_zooms()
            voxel_volume = np.prod(voxel_dims)
            tumor_volume = tumor_voxels * voxel_volume
            logger.info(f"Patient {patient_id}: Voxel dimensions={voxel_dims}mm | Tumor volume={tumor_volume:.2f}mm³")
            print(f"Voxel dimensions: {voxel_dims}mm, Tumor volume: {tumor_volume:.2f}mm³")

            tumor_indices = np.argwhere(tumor_mask)
            x = tumor_indices[:, 0] / mask_data.shape[0]
            y = tumor_indices[:, 1] / mask_data.shape[1]
            z = tumor_indices[:, 2] / mask_data.shape[2]
            coords = np.column_stack((x, y, z))

            multi_seq_voxels = []
            for sd in norm_seq_list:
                vox = sd[tumor_mask].reshape(-1, 1)
                vox = (vox - np.mean(vox)) / (np.std(vox) + 1e-6)
                multi_seq_voxels.append(vox)
            multi_seq_voxels = np.hstack(multi_seq_voxels)

            tumor_local_std = self.enhance_features(norm_seq_list[self.local_std_seq_idx], tumor_mask, voxel_dims)
            tumor_features = np.hstack((multi_seq_voxels, coords, tumor_local_std))

            if tumor_voxels < 1000:
                current_cluster_range = range(2, 7)
            else:
                current_cluster_range = range(2, 10)

            best_cluster_num, ch_scores, cluster_range = self.find_best_cluster_number(tumor_features, current_cluster_range)
            print(f"Optimal number of clusters: {best_cluster_num} (Multi‑seq CH score)")

            kmeans = KMeans(n_clusters=best_cluster_num, random_state=42, n_init=5)
            clusters = kmeans.fit_predict(tumor_features)

            cluster_map = np.zeros_like(mask_data, dtype=np.int16)
            cluster_map[tumor_mask] = clusters + 1
            cluster_nii = nib.Nifti1Image(cluster_map, mask_nii.affine, mask_nii.header)
            cluster_save_path = os.path.join(patient_out_dir, f"{patient_id}_multi_seq_mri_cluster.nii.gz")
            nib.save(cluster_nii, cluster_save_path)

            ith_score, max_cluster_ratio = self.calculate_ith_score(cluster_map, mask_data, voxel_volume, patient_id)

            unique_labels = np.unique(cluster_map[tumor_mask])
            unique_labels = unique_labels[unique_labels != 0]
            cluster_volumes = [np.sum((cluster_map == lb) & tumor_mask) * voxel_volume for lb in unique_labels]

            cluster_quality = "Pass" if max_cluster_ratio <= self.max_cluster_ratio else "Warning"
            self.results.append({
                "PatientID": patient_id,
                "TumorVoxels": int(tumor_voxels),
                "OptimalClusterNum": best_cluster_num,
                "ITHscore": round(ith_score, 4),
                "TumorVolume_mm3": round(tumor_volume, 2),
                "MaxClusterRatio": round(max_cluster_ratio, 4),
                "ClusterQuality": cluster_quality,
                "UsedLocalStdSeq": self.local_std_seq_idx + 1,
                "TotalMRISequences": self.seq_num
            })
            print(f"✅ {patient_id} done | ITHscore:{ith_score:.4f} MaxClusterRatio:{max_cluster_ratio:.3f}")

        except Exception as e:
            err_msg = f"Patient {patient_id} failed: {str(e)}"
            logger.error(err_msg, exc_info=True)
            print(f"❌ {err_msg} ——— skip and continue")
            self.error_patients.append(patient_id)

    def run_batch(self):
        if not self.select_folders():
            print("User cancelled setup, exit.")
            return

        file_list = [f for f in os.listdir(self.image_dirs[0]) if f.endswith(".nii.gz")]
        total = len(file_list)
        print(f"\nTotal patients to process: {total}")

        for idx, fname in enumerate(file_list):
            print(f"\n==== Progress {idx+1}/{total} ====")
            self.process_single_patient(fname)

        print("\n" + "="*60)
        if len(self.error_patients) > 0:
            print(f"⚠️ Total failed patients count: {len(self.error_patients)}")
            print(f"⚠️ Failed patient ID list: {self.error_patients}")
            logger.info(f"Failed patient IDs: {self.error_patients}")
        else:
            print("✅ All patients processed without error")
            logger.info("All patients processed without error")
        print("="*60)

        import pandas as pd
        out_df = pd.DataFrame(self.results)
        excel_path = os.path.join(self.output_dir, "MultiSeq_MRI_ITHscore_Results.xlsx")
        out_df.to_excel(excel_path, index=False)
        print(f"\n✅ Result excel saved: {excel_path}")
        logger.info(f"Result excel saved:{excel_path}")


if __name__ == "__main__":
    analyzer = MultiSeqMRI_ITHAnalyzer(
        smooth_sigma=1.0,
        max_cluster_ratio=0.85,
        min_tumor_voxels=150,
        lower_percentile=2,
        upper_percentile=98
    )
    analyzer.run_batch()
    print("\n==== Multi‑sequence MRI ITH Analysis Finished ====")
