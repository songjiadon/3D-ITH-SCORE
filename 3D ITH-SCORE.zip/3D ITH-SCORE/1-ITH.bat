@echo off
chcp 65001
cd %~dp0

REM Activate the specified Anaconda environment
call C:\daima\SONG1\python.exe 1-ITH-CT.py

REM Pause to view output
pause

REM Optional: Deactivate the environment after script execution
call conda deactivate
